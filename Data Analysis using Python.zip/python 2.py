#!/usr/bin/env python
# coding: utf-8

# In[1]:


import math


# #### 1. Write a program that reads an integer from the user. Then your program should display a message indicating whether the integer is even or odd.

# In[2]:


a=int(input("enter a number: "))
if a==0:
    print("entered number is neither even nor odd")
elif a%2==0:
    print("entered number is even")
else:
    print("entered number is odd")


# #### 2. Write a program that implements the conversion from human years to dog years described in the previous paragraph. Ensure that your program works correctly for conversions of less than two human years and for conversions of two or more human years. Your program should display an appropriate error message if the user enters a negative number.

# In[3]:


dog_age=float(input("enter dog age: "))
human_age=0
if dog_age<0:
    print("Please enter valid age")
elif 0<=dog_age<1:
    human_age=dog_age*15.0
    print(f"{:.2f} human years")
elif 1<=dog_age<2:
    


# #### 3. Create a program that reads a letter of the alphabet from the user. If the user enters a, e, i, o or u then your program should display a message indicating that the entered letter is a vowel. If the user enters y then your program should display a message indicating that sometimes y is a vowel, and sometimes y is a consonant. Otherwise your program should display a message indicating that the letter is a consonant.

# In[ ]:


alp=input("enter a alphabet")
vow=['a','e','i','o','u']
if alp in vow:
    print("entered letter is a vowel")
elif alp=='y':
    print("sometimes y is a vowel sometimes y is a consonant")
else:
    print("entered letter is consonant")


# #### 4. Write a program that determines the name of a shape from its number of sides. Read the number of sides from the user and then report the appropriate name as part of a meaningful message. Your program should support shapes with anywhere from 3 up to (and including) 10 sides. If a number of sides outside of this range is entered then your program should display an appropriate error message.

# In[4]:


inp=int(input("enter no.of sides: "))
d={3:'triangle',
  4:['square','rectangle'],
  5:'pentagon',
  6:'hexagon',
  7:'septagon',
  8:'octagon',
  9:'nanogon',
  10:'decagon'}
if inp<=2:
    print("enter a number greater than 2")
else:
    print(d[inp])


# #### 5. The length of a month varies from 28 to 31 days. In this exercise you will create a program that reads the name of a month from the user as a string. Then your program should display the number of days in that month. Display “28 or 29 days” for February so that leap years are addressed.

# In[5]:


mon=input("enter month: ")
feb=['february','feb']
m1=['jan','january','mar','march','may','jul','july','aug','august','oct','october','dec','december']
m2=['apr','april','jun','june','sep','september','nov','november']
if mon.lower() in feb:
    print(f"{mon} has 28 or 29 days.")
elif mon.lower() in m1:
    print(f"{mon} has 31 days.")
elif mon.lower() in m2:
    print(f"{mon} has 30 days.")
else:
    print("enter a valid input")


# #### 6. The following table lists the sound level in decibels for several common noises.Noise Decibel level (dB) Jackhammer 130 Gas lawnmower 106 Alarm clock 70 Quiet room 40 Write a program that reads a sound level in decibels from the user. If the user enters a decibel level that matches one of the noises in the table then your program should display a message containing only that noise. If the user enters a number of decibels between the noises listed then your program should display a message indicating which noises the level is between. Ensure that your program also generates reasonable output for a value smaller than the quietest noise in the table, and for a value larger than the loudest noise in the table.

# In[6]:


n=int(input("enter noice level in decibles: "))
noi={40:'Quite room',70:'Alarm clock',106:'Gas lawnmower',130:'Jackhammer'}
if n in noi:
    print(noi[n])
elif n>40 and n<70:
    print("Yoyr noice level is in between Quite room and Alarm clock")
elif n>70 and n<106:
    print("Your noice level is in between Alarm clock and Gas lawnmower")
elif n>106 and n<130:
    print("Your noice level is in between Gas lawnmower and Jackhammer")
elif n<70:
    print("Your noice level is lower than Quite room")
else:
    print("Your noice level is greater than Jackhammer")


# #### Begin by writing a program that reads the name of a note from the user and displays the note’s frequency. Your program should support all of the notes listed previously.

# In[7]:


note=input("enter note: ")
k=int(note[1])
if note[0]=='A' and (0<=k<=8):
    if note=='A4':
        print(440.00)
    else:
        x1=440.00*math.pow(2,k-4)
        print(round(x1,2))
elif note[0]=='B' and (0<=k<=8):
    if note=='B4':
        print(493.88)
    else:
        x2=493.88*math.pow(2,k-4)
        print(round(x2,2))
elif note[0]=='C' and (0<=k<=8):
    if note=='C4':
        print(261.63)
    else:
        x3=261.63*math.pow(2,k-4)
        print(round(x3,2))
elif note[0]=='D' and (0<=k<=8):
    if note=='D4':
        print(293.66)
    else:
        x4=293.66*math.pow(2,k-4)
        print(round(x4,2))
elif note[0]=='E' and (0<=k<=8):
    if note=='E4':
        print(329.63)
    else:
        x5=329.63*math.pow(2,k-4)
        print(round(x5,2))
elif note[0]=='F' and (0<=k<=8):
    if note=='F4':
        print(349.23)
    else:
        x6=349.23*math.pow(2,k-4)
        print(round(x6,2))       
elif note[0]=='G' and (0<=k<=8):
    if note=='G4':
        print(392.00)
    else:
        x7=392.00*math.pow(2,k-4)
        print(round(x7,2))
else:
    print("invalid input")


# #### write a program that reverses that process. Begin by reading a frequency from the user. If the frequency is within one Hertz of a value listed in the table in the previous question then report the name of the note.

# In[8]:


rev=float(input("enter frequency: "))
if 260<=rev<=262:
    print('C4')
elif 292<=rev<=294:
    print('D4')
elif 328<=rev<=330:
    print('E4')
elif 348<=rev<=350:
    print('F4')
elif 391<=rev<=393:
    print('G4')
elif 439<=rev<=441:
    print('A4')
elif 492<=rev<=494:
    print('B4')
else:
    print('input is in invalid range')


# #### Write a program that reads a wavelength from the user and reports its color. Display an appropriate error message if the wavelength entered by the user is outside of the visible spectrum.

# In[9]:


w=float(input("Enter Wavelength: "))
if 380<=w<450:
    print("Voilet")
elif 450<=w<495:
    print("Blue")
elif 495<=w<570:
    print("Green")
elif 570<=w<590:
    print("Yellow")
elif 590<=w<620:
    print("Orange")
elif 620<=w<750:
    print("Red")
else:
    print('input is in invalid range')


# #### Write a main program that demonstrates your function. Your function should read a list of numbers from the user and remove the two largest and two smallest values from it. Display the list with the outliers removed, followed by the original list. Your program should generate an appropriate error message if the user enters less than 4 values.

# In[19]:


def remove_outliers(lst):
    lst1=[]
    ol=[]
    if len(lst)<=4:
        print("enter more than 4 elements")
    else:
        lst1=sorted(lst)
        ol.extend(lst1[:2])
        ol.extend(lst1[-2:])
        print(f"original list: {lst}, outliers : {ol}")
    
    
ln=int(input("enter range"))
lst=[]
for i in range(0,ln):
    el=int(input())
    lst.append(el)
#lst=[3,56,2,34,1,50,23,12,24,11,22]
remove_outliers(lst)

    
    
        


# #### Write a main program that demonstrates your function. It should read a string from the user and display all of the words in the string with the punctuation marks removed.

# In[24]:


import string


# In[36]:


def punct(st):
       st=st.translate(str.maketrans('','',string.punctuation))
       kk=st.split()
       return kk
#st="Examples of contractions include: don’t, isn’t, and wouldn’t."
st=input("enter a sentence with punctuation")
print(punct(st))


# In[ ]:





# In[ ]:




