#!/usr/bin/env python
# coding: utf-8

# In[1]:


import seaborn as sns
import numpy as np
get_ipython().run_line_magic('matplotlib', 'inline')
import pandas as pd


# In[2]:


cast = pd.read_csv('cast.csv')
cast.head(10)


# In[3]:


cast.shape


# ### How many movies are listed in the titles dataframe?

# In[65]:


len(cast['title'].unique())


# In[66]:


#172294 movies are listed


# ### What are the earliest two films listed in the titles dataframe?

# In[6]:


cast.groupby(['title','year']).size().reset_index().sort_values(by=['year'])[:2]


# In[ ]:





# ### How many movies have the title "Hamlet"?

# In[67]:


len(cast[cast['title'].str.contains('Hamlet')])


# In[8]:


# 921 movies have "Hamlet" in its title


# ### How many movies are titled "North by Northwest"?

# In[68]:


len(cast[cast['title']=='North by Northwest'])


# In[10]:


# there are 112 movies titled "North by Northwest"


# ### When was the first movie titled "Hamlet" made?

# In[11]:


cast[cast['title']=='Hamlet'].sort_values(by=['year'])[:1]


# In[12]:


# The first movie titled "Hamlet" made in year 1910


# ### List all of the "Treasure Island" movies from earliest to most recent.

# In[70]:


dd=cast[cast['title']=='Treasure Island'].sort_values(by=['year'])
dd[['title','year']].reset_index()


# In[ ]:





# ### How many movies were made in the year 1950?

# In[71]:


len(cast[cast['year']==1950])


# In[15]:


# 22006 movies were made in 1950


# ### How many movies were made in the year 1960?

# In[72]:


len(cast[cast['year']==1960])


# In[17]:


# 18456 movies were made in 1960


# ### How many movies were made from 1950 through 1959?

# In[73]:


len(cast[cast['year'].between(1950,1959)])


# In[19]:


#210986 movies were made between 1959 and 1959


# ### In what years has a movie titled "Batman" been released?

# In[75]:


bat=cast[cast['title']=='Batman']
bat['year'].value_counts()


# In[21]:


# Batman has released in 1989 and 1943


# ### How many roles were there in the movie "Inception"?

# In[22]:


rol=cast[cast['title']=='Inception']
len(rol['character'])


# In[23]:


# 77 roles were there in movie Inception


# ### How many roles in the movie "Inception" are NOT ranked by an "n" value?

# In[24]:


cast[cast['title']=='Inception'].isnull().sum()


# In[25]:


# 26 roles are not ranked by "n" value


# ### But how many roles in the movie "Inception" did receive an "n" value?

# In[26]:


cast[cast['title']=='Inception'].notnull().sum()


# In[27]:


# 51 roles in the movie Inception received an "n" value


# ### Display the cast of "North by Northwest" in their correct "n"-value order, ignoring roles that did not earn a numeric "n" value.

# In[28]:


cast[cast['title']=='North by Northwest'].sort_values(by=['n']).dropna()


# In[ ]:





# ### Display the entire cast, in "n"-order, of the 1972 film "Sleuth".

# In[29]:


#sle=cast[cast['title']=='Sleuth']
#sle[sle['year']==1972].sort_values(by=['n'])
cast[(cast.title=='Sleuth') & (cast.year==1972)].sort_values(by=['n'])


# In[ ]:





# ### Now display the entire cast, in "n"-order, of the 2007 version of "Sleuth".

# In[30]:


cast[(cast.title=='Sleuth') & (cast.year==2007)].sort_values(by=['n'])


# In[ ]:





# ### How many roles were credited in the silent 1921 version of Hamlet?

# In[31]:


cast[(cast.title == 'Hamlet') & (cast.year == 1921) & (cast.name.str.contains('Branagh'))]
#len(df['character'])


# In[32]:


# 0 roles were credited in the silent 1921 version of Hamlet


# ### How many roles were credited in Branagh’s 1996 Hamlet?

# In[33]:


cast[(cast.title == 'Hamlet') & (cast.year == 1996) & (cast.name.str.contains('Branagh'))]


# In[34]:


# 1 role was credited in Branagh’s 1996 Hamlet?


# ### How many "Hamlet" roles have been listed in all film credits through history?

# In[35]:


len(cast[(cast.title=='Hamlet')])


# In[ ]:


# 313 Hamlet roles have been created in all film credits through history


# ### How many people have played an "Ophelia"?

# In[36]:


len(cast[(cast.character=='Ophelia')])


# In[37]:


#111 people have played Ophelia role


# ### How many people have played a role called "The Dude"?

# In[38]:


len(cast[(cast.character=='The Dude')])


# In[39]:


# 18 people have played a role called "The Dude"


# ### How many people have played a role called "The Stranger"?

# In[40]:


len(cast[(cast.character=='The Stranger')])


# In[41]:


# 208 people have played a role called "The Stranger"


# ### How many roles has Sidney Poitier played throughout his career?

# In[42]:


len(cast[(cast.name=='Sidney Poitier')])


# In[43]:


# Sidney Poitier has played 43 roles throughout his career


# ### How many roles has Judi Dench played?

# In[44]:


len(cast[(cast.name=='Judi Dench')])


# In[45]:


# Judi Dench has played 55 roles throughout his career


# ### List the supporting roles (having n=2) played by Cary Grant in the 1940s, in order by year.

# In[46]:


df=cast[(cast.name=='Cary Grant') & ((cast.year>=1940) & (cast.year<=1949)) & (cast.n==2)].sort_values(by=['year'])
df['character']


# In[ ]:





# ### List the leading roles that Cary Grant played in the 1940s in order by year.

# In[76]:


df=cast[(cast.name=='Cary Grant') & ((cast.year>=1940) & (cast.year<=1949)) & (cast.n==1)].sort_values(by=['year'])
df['character'].reset_index()


# In[ ]:





# ### How many roles were available for actors in the 1950s?

# In[48]:


len(cast[(cast.type=='actor') & ((cast.year>=1900) & (cast.year<=1959))])


# In[49]:


# 539923 roles were available for actors in 1950's


# ### How many roles were available for actresses in the 1950s?

# In[50]:


len(cast[(cast.type=='actress') & ((cast.year>=1900) & (cast.year<=1959))])


# In[51]:


# 195256 roles were available for actors in 1950's


# ### How many leading roles (n=1) were available from the beginning of film history through 1980?

# In[56]:


cast.sort_values(by=['year'])[:1].year


# In[59]:


len(cast[((cast.year>=1894) & (cast.year<=1980)) & (cast.n==1)])


# In[ ]:


# 63924 leading roles were available from the beginning of film history through 1980


# ### How many non-leading roles were available through from the beginning of film history through 1980?

# In[60]:


len(cast[((cast.year>=1894) & (cast.year<=1980)) & (cast.n!=1)])


# In[ ]:


# 1094780 non leading roles were available from the beginning of film history through 1980


# ### How many roles through 1980 were minor enough that they did not warrant a numeric "n" rank?

# In[63]:


len(cast[(cast.year==1980) & (cast.n.isnull()==True)])


# In[ ]:


# 4227 roles through 1980 were minor enough that they did not warrant a numeric "n" rank

