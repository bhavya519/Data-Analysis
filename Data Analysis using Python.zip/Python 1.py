#!/usr/bin/env python
# coding: utf-8

# ## Python Basics

# ### 1. Simple Message: Store a message in a variable, and then print that message.

# In[1]:


msg="Hi! Welcome."
print(msg)


# ### 2. Store a message in a variable and print that message. Then change the value of your variable to a new message and print the new message.

# In[2]:


msg1="This is the message in variable \"msg1\"."
print(msg1)


# In[3]:


msg1="The message changed in variable \"msg1\"."
print(msg1)


# ### 3. Store a person’s name in a variable and print a message to that person. Your message should be simple, such as, “Hello Eric, would you like to learn some Python today?”
# 

# In[4]:


name="Bhavya"
print(f"Hello! {name}, Lets learn some Python basics.")


# ### 4. Find a quote from a famous person you admire. Print the quote and the name of its author. Your output should look something like the following, including the quotation marks: Albert Einstein once said, “A person who never made a mistake never tried anything new.”
# 

# In[5]:


print("Jhon Rim once said, \"Suffer the pain of Discipline or Suffer the pain of regret\".")


# ### 5. Repeat Exercise 4, but this time store the famous person’s name in a variable called famous_person. Then compose your message and store it in a new variable called message. Print your message.

# In[6]:


famous_person="Jhon Rim"
message="Suffer the pain of Discipline or suffer the pain of regret"
print(f"{famous_person} once said, \"{message}\".")


# ### 6. Write addition, subtraction, multiplication, and division operations that each result in the number 8. Be sure to enclose your operations in print statements to see the results. You should create four lines that look like this: print (5 + 3). Your output should simply be four lines with the number 8 appearing once on each line.

# In[8]:


print(5+3)
print(10-2)
print(4*2)
print(16//2)


# ### 7. Store your favourite number in a variable. Then, using that variable, create a message that reveals your favourite number. Print that message.
# 

# In[11]:


a=2
b="My Favourite number is "+ str(a)
print(b)


# ### 8. Choose two of the programs you’ve written and add at least one comment to each. If you don’t have anything specific to write because your programs are too simple at this point, just add your name and the current date at the top of each program file. Then write one sentence describing what the program does.

# In[12]:


# Bhavya 23-10-2022
# The following program stores a name in a variable and prints name with some extra message.
name="Bhavya"
print(f"Hello! {name}, Lets learn some Python basics.")


# In[13]:


# Bhavya 23-10-2022
# The following program does addition, subtraction, multiplication, and division that results 8 everytime.
print(6+2)
print(16-8)
print(8*1)
print(24//3)


# ### 9. Store the names of a few of your friends in a list called names. Print each person’s name by accessing each element in the list, one at a time.

# In[18]:


names=['Chowdary','Rushika','Shalini','Jay',"Sushmitha","indu"]
for i in names:
    print(i)


# ### 10.Start with the list you used in Exercise 9, but instead of just printing each person’s name, print a message to them. The text of each message should be the same, but each message should be personalized with the person’s name.
# 

# In[19]:


for i in names:
    print(f"Hi! {i}, Have a good day:)")


# ### 11.Think of your favourite mode of transportation, such as a motorcycle or a car, and make a list that stores several examples. Use your list to print a series of statements about these items, such as “I would like to own a Honda motorcycle.”

# In[25]:


fav=['Airlines','Car','Bike','Bicycle']
print(f"Vistara {fav[0]} is the best in India.")
print(f"When comes to luxuary who can avoid BMW {fav[1]}.")
print(f"I always wish to ride Royal Enfield {fav[2]}.")
print(f"Its fun to ride {fav[3]}.")


# In[ ]:




