#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().run_line_magic('matplotlib', 'inline')
import pandas as pd
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")


# In[2]:


#titles = pd.read_csv('data/titles.csv')
#titles.head()


# In[3]:


cast = pd.read_csv('cast.csv')
cast.head()


# ### What are the ten most common movie names of all time?

# In[4]:


cast.groupby(['title']).size().reset_index().rename(columns={0:'count'}).sort_values(by=['count'],ascending=False)[:10]
#apply(lambda a: a.sort_values(by=['count']))


# In[ ]:





# ### Which three years of the 1930s saw the most films released?

# In[5]:


cast[(cast.year>=1930) & (cast.year<=1939)].groupby(['year']).size().reset_index().rename(columns={0:'count'})[:3]


# In[ ]:





# ### Plot the number of films that have been released each decade over the history of cinema.

# In[6]:


cast['bin']=pd.cut(cast['year'],[1890,1900,1910,1920,1930,1940,1950,1960,1970,1980,1990,2000,2010,2020,2030],labels=['d1','d2','d3','d4','d5','d6','d7','d8','d9','d10','d11','d12','d13','d14'])


# In[7]:


cast['bin'].value_counts()


# In[8]:


#sns.displot(cast['bin'])


# In[9]:


sns.countplot(cast['bin'])


# ### Plot the number of "Hamlet" films made each decade.

# In[20]:


df1=cast[(cast.title=='Hamlet')].groupby(['bin']).size().reset_index().rename(columns={0:'count'})
df1


# In[21]:


sns.barplot(x=df1['bin'],y=df1['count'])


# ### Plot the number of "Rustler" characters in each decade of the history of film.

# In[25]:


df2=cast[(cast.character=='Rustler')].groupby(['bin','character']).size().reset_index().rename(columns={0:'count'})
df2


# In[26]:


sns.barplot(x=df2['bin'],y=df2['count'])


# ### Plot the number of "Hamlet" characters each decade.

# In[27]:


df3=cast[(cast.character=='Hamlet')].groupby(['bin','character']).size().reset_index().rename(columns={0:'count'})
df3


# In[28]:


sns.barplot(x=df3['bin'],y=df3['count'])


# ### What are the 11 most common character names in movie history?

# In[34]:


cast.groupby(['character']).size().reset_index().rename(columns={0:'count'}).sort_values(by=['count'],ascending=False)[:11]


# In[ ]:





# ### Who are the 10 people most often credited as "Herself" in film history?

# In[41]:


cast[(cast.character=='Herself')].groupby(['name','character']).size().reset_index().rename(columns={0:'count'}).sort_values(by=['count'],ascending=False)[:10]


# In[ ]:





# ### Who are the 10 people most often credited as "Himself" in film history?

# In[42]:


cast[(cast.character=='Himself')].groupby(['name','character']).size().reset_index().rename(columns={0:'count'}).sort_values(by=['count'],ascending=False)[:10]


# In[ ]:





# ### Which actors or actresses appeared in the most movies in the year 1945?

# In[49]:


cast[((cast.type=='actor') | (cast.type=='actress')) & (cast.year==1945)].groupby(['name','type','year']).size().reset_index().rename(columns={0:'count'}).sort_values(by=['count'],ascending=False)[:10]


# In[ ]:





# ### Which actors or actresses appeared in the most movies in the year 1985?

# In[50]:


cast[((cast.type=='actor') | (cast.type=='actress')) & (cast.year==1985)].groupby(['name','type','year']).size().reset_index().rename(columns={0:'count'}).sort_values(by=['count'],ascending=False)[:10]


# In[ ]:





# ### Plot how many roles Mammootty has played in each year of his career.

# In[55]:


df4=cast[(cast.name=='Mammootty')].groupby(['name','year']).size().reset_index().rename(columns={0:'count'}).sort_values(by=['count'],ascending=False)
df4


# In[56]:


sns.barplot(x=df4['year'],y=df4['count'])


# ### What are the 10 most frequent roles that start with the phrase "Patron in"?

# In[60]:


cast[(cast.character.str.startswith('Patron in'))].groupby(['character']).size().reset_index().rename(columns={0:'count'}).sort_values(by=['count'],ascending=False)[:10]


# In[ ]:





# ### What are the 10 most frequent roles that start with the word "Science"?

# In[61]:


cast[(cast.character.str.startswith('Science'))].groupby(['character']).size().reset_index().rename(columns={0:'count'}).sort_values(by=['count'],ascending=False)[:10]


# In[ ]:





# ### Plot the n-values of the roles that Judi Dench has played over her career.

# In[67]:


df5=cast[(cast.name=='Judi Dench')].groupby(['n','character']).size().reset_index().rename(columns={0:'count'}).sort_values(by=['count'],ascending=False)
df5


# In[70]:


sns.countplot(df5['n'])


# ### Plot the n-values of Cary Grant's roles through his career.

# In[71]:


df6=cast[(cast.name=='Cary Grant')].groupby(['n','character']).size().reset_index().rename(columns={0:'count'}).sort_values(by=['count'],ascending=False)
df6


# In[72]:


sns.countplot(df6['n'])


# ### Plot the n-value of the roles that Sidney Poitier has acted over the years.

# In[73]:


df7=cast[(cast.name=='Sidney Poitier')].groupby(['n','character']).size().reset_index().rename(columns={0:'count'}).sort_values(by=['count'],ascending=False)
df7


# In[74]:


sns.countplot(df7['n'])


# ### How many leading (n=1) roles were available to actors, and how many to actresses, in the 1950s?

# In[81]:


cast[(cast.n==1) & ((cast.year>=1950) & (cast.year<=1959))].groupby(['type','n','year']).size().reset_index().rename(columns={0:'count'})


# In[ ]:





# ### How many supporting (n=2) roles were available to actors, and how many to actresses, in the 1950s?

# In[82]:


cast[(cast.n==2) & ((cast.year>=1950) & (cast.year<=1959))].groupby(['type','n','year']).size().reset_index().rename(columns={0:'count'})


# In[ ]:




